package Login;

import java.awt.Color;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Registro extends javax.swing.JFrame {

     int xMouse, yMouse;
    
    public Registro() {
        initComponents();
        this.setLocationRelativeTo(this);
        
        SetImageLabelLogo(logo, "src/img/Logo150x150.png");
        SetImageLabelBotonRegistrarse(JLBotonRegistrarse, "src/img/botonNZ.png" );
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Bg = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        JLUser = new javax.swing.JLabel();
        JTNombre = new javax.swing.JTextField();
        JSepNombre = new javax.swing.JSeparator();
        JTUser = new javax.swing.JTextField();
        JSepUser = new javax.swing.JSeparator();
        JPassword = new javax.swing.JPasswordField();
        jSepPassword = new javax.swing.JSeparator();
        JConfiPassword = new javax.swing.JPasswordField();
        JSepConfiPassword = new javax.swing.JSeparator();
        JLBotonRegistrarse = new javax.swing.JLabel();
        Cerrar = new javax.swing.JLabel();
        JLCrearCuenta = new javax.swing.JLabel();
        ErrorPassword = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        Bg.setBackground(new java.awt.Color(255, 233, 177));
        Bg.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Bg.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                BgMouseDragged(evt);
            }
        });
        Bg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BgMousePressed(evt);
            }
        });
        Bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo.setBackground(new java.awt.Color(255, 255, 255));
        logo.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        logo.setForeground(new java.awt.Color(0, 0, 255));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        logo.setRequestFocusEnabled(false);
        Bg.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 80, 80));

        JLUser.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        JLUser.setForeground(new java.awt.Color(0, 0, 25));
        JLUser.setText("REGISTRO");
        JLUser.setToolTipText("");
        Bg.add(JLUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, 151, 37));

        JTNombre.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        JTNombre.setForeground(java.awt.Color.gray);
        JTNombre.setText("Nombre Completo");
        JTNombre.setBorder(null);
        JTNombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        JTNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                JTNombreMousePressed(evt);
            }
        });
        JTNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTNombreActionPerformed(evt);
            }
        });
        Bg.add(JTNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 150, 317, 45));

        JSepNombre.setForeground(new java.awt.Color(0, 0, 0));
        Bg.add(JSepNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 195, 317, 10));

        JTUser.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        JTUser.setForeground(java.awt.Color.gray);
        JTUser.setText(" Ejemplo@ejemplo.com");
        JTUser.setBorder(null);
        JTUser.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        JTUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                JTUserMousePressed(evt);
            }
        });
        JTUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTUserActionPerformed(evt);
            }
        });
        Bg.add(JTUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 210, 317, 45));

        JSepUser.setForeground(new java.awt.Color(0, 0, 0));
        Bg.add(JSepUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 255, 317, 10));

        JPassword.setForeground(java.awt.Color.gray);
        JPassword.setText("jPasswordField1");
        JPassword.setBorder(null);
        JPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                JPasswordMousePressed(evt);
            }
        });
        JPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordActionPerformed(evt);
            }
        });
        Bg.add(JPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 270, 317, 45));

        jSepPassword.setForeground(new java.awt.Color(0, 0, 0));
        Bg.add(jSepPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 315, 317, 10));

        JConfiPassword.setForeground(java.awt.Color.gray);
        JConfiPassword.setText("jPasswordField1");
        JConfiPassword.setBorder(null);
        JConfiPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                JConfiPasswordMousePressed(evt);
            }
        });
        JConfiPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JConfiPasswordActionPerformed(evt);
            }
        });
        Bg.add(JConfiPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 330, 317, 45));

        JSepConfiPassword.setForeground(new java.awt.Color(0, 0, 0));
        Bg.add(JSepConfiPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 375, 317, 10));

        JLBotonRegistrarse.setFont(new java.awt.Font("Roboto Light", 0, 18)); // NOI18N
        JLBotonRegistrarse.setForeground(java.awt.Color.yellow);
        JLBotonRegistrarse.setText("REGISTRARSE");
        JLBotonRegistrarse.setToolTipText("");
        JLBotonRegistrarse.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JLBotonRegistrarse.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLBotonRegistrarse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JLBotonRegistrarseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JLBotonRegistrarseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JLBotonRegistrarseMouseExited(evt);
            }
        });
        Bg.add(JLBotonRegistrarse, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 400, 225, 35));

        Cerrar.setBackground(new java.awt.Color(0, 0, 20));
        Cerrar.setFont(new java.awt.Font("Roboto Black", 0, 28)); // NOI18N
        Cerrar.setForeground(java.awt.Color.yellow);
        Cerrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cerrar.setText("X");
        Cerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Cerrar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Cerrar.setOpaque(true);
        Cerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CerrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CerrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CerrarMouseExited(evt);
            }
        });
        Bg.add(Cerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(342, 2, 25, 25));

        JLCrearCuenta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        JLCrearCuenta.setText("¿Ya tienes Cuenta? Ingresa aqui");
        JLCrearCuenta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JLCrearCuenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JLCrearCuentaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JLCrearCuentaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JLCrearCuentaMouseExited(evt);
            }
        });
        Bg.add(JLCrearCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 450, 200, -1));

        ErrorPassword.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        ErrorPassword.setForeground(new java.awt.Color(255, 0, 255));
        ErrorPassword.setText("Las Contraseñas no coinciden");
        Bg.add(ErrorPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 120, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Bg, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Bg, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JTNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTNombreMousePressed
        if (JTNombre.getText().equals("Nombre Completo") || JTNombre.getText().equals("Este campo es obligatorio")){
                JTNombre.setText("");
                JTNombre.setForeground(Color.BLACK);
        }
        if (JTUser.getText().equals("")){
                JTUser.setText(" Ejemplo@ejemplo.com");
                JTUser.setForeground(Color.GRAY);
         }
        if (String.valueOf(JPassword.getPassword()).isEmpty()){
                JPassword.setText("jPasswordField1");
                JPassword.setForeground(Color.GRAY);
        }
        if (String.valueOf(JConfiPassword.getPassword()).isEmpty()){
                JConfiPassword.setText("jPasswordField1");
                JConfiPassword.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_JTNombreMousePressed

    private void JTNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JTNombreActionPerformed

    private void JConfiPasswordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JConfiPasswordMousePressed
        if (String.valueOf(JConfiPassword.getPassword()).equals("jPasswordField1")){
            JConfiPassword.setText("");
            JConfiPassword.setForeground(Color.BLACK);
        }
        if (String.valueOf(JPassword.getPassword()).isEmpty()){
                JPassword.setText("jPasswordField1");
                JPassword.setForeground(Color.GRAY);
        }
        if ( JTNombre.getText().equals("") || JTNombre.getText().equals("Este campo es obligatorio")){
                JTNombre.setText("Nombre Completo");
                JTNombre.setForeground(Color.gray);
        }
        if (JTUser.getText().equals("")){
                JTUser.setText(" Ejemplo@ejemplo.com");
                JTUser.setForeground(Color.GRAY);
         }
        
    }//GEN-LAST:event_JConfiPasswordMousePressed

    private void JConfiPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JConfiPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JConfiPasswordActionPerformed

    private void JLBotonRegistrarseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLBotonRegistrarseMouseClicked
        int cuentas = 0 ;
        String[] name = null, user = null, password = null;
         main comprobar = new main( );
        if(!String.copyValueOf(JPassword.getPassword()).equals(String.copyValueOf(JConfiPassword.getPassword()))){
            ErrorPassword.setVisible(true);
        }else{
             ErrorPassword.setVisible(false);
        }
        if(!"".equals(JTNombre.getText())){
                JTNombre.setForeground(Color.magenta);
                JTNombre.setText("Este campo es obligatorio");
        }
        if (!"".equals(JTNombre.getText()) &&  String.copyValueOf(JPassword.getPassword()).equals(String.copyValueOf(JConfiPassword.getPassword()))){
                name[cuentas] = JTNombre.getText();
                user[cuentas] = JTUser.getText();
                password[cuentas] = String.copyValueOf(JPassword.getPassword());
                cuentas = cuentas + 1;
        }
    }//GEN-LAST:event_JLBotonRegistrarseMouseClicked

    private void JLBotonRegistrarseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLBotonRegistrarseMouseEntered
        JLBotonRegistrarse.setForeground(Color.magenta);
    }//GEN-LAST:event_JLBotonRegistrarseMouseEntered

    private void JLBotonRegistrarseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLBotonRegistrarseMouseExited
        JLBotonRegistrarse.setForeground(Color.yellow);
    }//GEN-LAST:event_JLBotonRegistrarseMouseExited

    private void CerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarMouseClicked
        System.exit(0);
    }//GEN-LAST:event_CerrarMouseClicked

    private void CerrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarMouseEntered
        Cerrar.setForeground(Color.MAGENTA);
    }//GEN-LAST:event_CerrarMouseEntered

    private void CerrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarMouseExited
        Cerrar.setForeground(Color.yellow);
    }//GEN-LAST:event_CerrarMouseExited

    private void JLCrearCuentaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLCrearCuentaMouseEntered
        JLCrearCuenta.setForeground(Color.MAGENTA);
    }//GEN-LAST:event_JLCrearCuentaMouseEntered

    private void JLCrearCuentaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLCrearCuentaMouseExited
        JLCrearCuenta.setForeground(Color.BLACK);
    }//GEN-LAST:event_JLCrearCuentaMouseExited

    private void BgMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BgMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();

        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_BgMouseDragged

    private void BgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BgMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_BgMousePressed

    private void JTUserMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTUserMousePressed
        if (JTUser.getText().equals(" Ejemplo@ejemplo.com")){
                JTUser.setText("");
                JTUser.setForeground(Color.black);
         }
        if (JTNombre.getText().equals("") || JTNombre.getText().equals("Este campo es obligatorio")){
                JTNombre.setText("Nombre Completo");
                JTNombre.setForeground(Color.gray);
        }
        if (String.valueOf(JPassword.getPassword()).isEmpty()){
                JPassword.setText("jPasswordField1");
                JPassword.setForeground(Color.GRAY);
        }
        if (String.valueOf(JConfiPassword.getPassword()).isEmpty()){
                JConfiPassword.setText("jPasswordField1");
                JConfiPassword.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_JTUserMousePressed

    private void JTUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTUserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JTUserActionPerformed

    private void JPasswordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JPasswordMousePressed
        if (String.valueOf(JPassword.getPassword()).equals("jPasswordField1")){
            JPassword.setText("");
            JPassword.setForeground(Color.BLACK);
        }
        if (String.valueOf(JConfiPassword.getPassword()).isEmpty()){
                JConfiPassword.setText("jPasswordField1");
                JConfiPassword.setForeground(Color.GRAY);
        }
        if (JTNombre.getText().equals("") || JTNombre.getText().equals("Este campo es obligatorio")){
                JTNombre.setText("Nombre Completo");
                JTNombre.setForeground(Color.gray);
        }
        if (JTUser.getText().equals("")){
                JTUser.setText(" Ejemplo@ejemplo.com");
                JTUser.setForeground(Color.GRAY);
         }
    }//GEN-LAST:event_JPasswordMousePressed

    private void JPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JPasswordActionPerformed

    private void JLCrearCuentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLCrearCuentaMouseClicked
        main irMain = new main();
        this.setVisible(false);
        irMain.setVisible(true);
    }//GEN-LAST:event_JLCrearCuentaMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Registro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registro().setVisible(true);
            }
        });
    }
    
    private void SetImageLabelLogo (JLabel labelName, String root ){
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(image.getImage().getScaledInstance(labelName.getWidth() , labelName.getHeight(), Image.SCALE_DEFAULT));
        labelName.setIcon(icon);
        this.repaint();
    }
    
     private void SetImageLabelBotonRegistrarse (JLabel labelName, String root ){
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(image.getImage().getScaledInstance(labelName.getWidth() , labelName.getHeight(), Image.SCALE_DEFAULT));
        labelName.setIcon(icon);
        this.repaint();
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Bg;
    private javax.swing.JLabel Cerrar;
    private javax.swing.JLabel ErrorPassword;
    private javax.swing.JPasswordField JConfiPassword;
    private javax.swing.JLabel JLBotonRegistrarse;
    private javax.swing.JLabel JLCrearCuenta;
    private javax.swing.JLabel JLUser;
    private javax.swing.JPasswordField JPassword;
    private javax.swing.JSeparator JSepConfiPassword;
    private javax.swing.JSeparator JSepNombre;
    private javax.swing.JSeparator JSepUser;
    private javax.swing.JTextField JTNombre;
    private javax.swing.JTextField JTUser;
    private javax.swing.JSeparator jSepPassword;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
