package Login;

import java.awt.Color;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class main extends javax.swing.JFrame {

    int xMouse, yMouse;
    
    public main() {
        initComponents();
        this.setLocationRelativeTo(this);
        
        
        //Para cambiar logo cambien la imagen y la ruta.
        SetImageLabelLogo(logo, "src/img/Logo150x150.png");
        SetImageLabelBotonIngresar(JLBotonIngresar, "src/img/botonNZ.png");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Bg = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        JLUser = new javax.swing.JLabel();
        JTUser = new javax.swing.JTextField();
        JSepUser = new javax.swing.JSeparator();
        JLPassword = new javax.swing.JLabel();
        JPassword = new javax.swing.JPasswordField();
        jSepPassword = new javax.swing.JSeparator();
        JLBotonIngresar = new javax.swing.JLabel();
        Cerrar = new javax.swing.JLabel();
        Recordar = new java.awt.Checkbox();
        JLOlvidarContraseña = new javax.swing.JLabel();
        JLCrearCuenta = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        Bg.setBackground(new java.awt.Color(255, 233, 177));
        Bg.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Bg.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                BgMouseDragged(evt);
            }
        });
        Bg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BgMousePressed(evt);
            }
        });
        Bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        logo.setBackground(new java.awt.Color(255, 255, 255));
        logo.setFont(new java.awt.Font("Roboto Black", 0, 24)); // NOI18N
        logo.setForeground(new java.awt.Color(0, 0, 255));
        logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        logo.setRequestFocusEnabled(false);
        Bg.add(logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, 150, 150));

        JLUser.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        JLUser.setForeground(new java.awt.Color(0, 0, 25));
        JLUser.setText("USUARIO");
        JLUser.setToolTipText("");
        Bg.add(JLUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 168, 151, 37));

        JTUser.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        JTUser.setForeground(java.awt.Color.gray);
        JTUser.setText(" Ejemplo@ejemplo.com");
        JTUser.setBorder(null);
        JTUser.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        JTUser.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                JTUserMousePressed(evt);
            }
        });
        JTUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTUserActionPerformed(evt);
            }
        });
        Bg.add(JTUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 205, 317, 45));

        JSepUser.setForeground(new java.awt.Color(0, 0, 0));
        Bg.add(JSepUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 251, 317, 10));

        JLPassword.setFont(new java.awt.Font("Roboto Black", 0, 18)); // NOI18N
        JLPassword.setForeground(new java.awt.Color(0, 0, 25));
        JLPassword.setText("CONTRASEÑA");
        Bg.add(JLPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 267, 151, 37));

        JPassword.setForeground(java.awt.Color.gray);
        JPassword.setText("jPasswordField1");
        JPassword.setBorder(null);
        JPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                JPasswordMousePressed(evt);
            }
        });
        JPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPasswordActionPerformed(evt);
            }
        });
        Bg.add(JPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 304, 317, 45));

        jSepPassword.setForeground(new java.awt.Color(0, 0, 0));
        Bg.add(jSepPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 349, 317, 10));

        JLBotonIngresar.setFont(new java.awt.Font("Roboto Light", 0, 18)); // NOI18N
        JLBotonIngresar.setForeground(java.awt.Color.yellow);
        JLBotonIngresar.setText("INGRESAR");
        JLBotonIngresar.setToolTipText("");
        JLBotonIngresar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JLBotonIngresar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLBotonIngresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JLBotonIngresarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JLBotonIngresarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JLBotonIngresarMouseExited(evt);
            }
        });
        Bg.add(JLBotonIngresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(67, 410, 225, 35));

        Cerrar.setBackground(new java.awt.Color(0, 0, 20));
        Cerrar.setFont(new java.awt.Font("Roboto Black", 0, 28)); // NOI18N
        Cerrar.setForeground(java.awt.Color.yellow);
        Cerrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cerrar.setText("X");
        Cerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Cerrar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Cerrar.setOpaque(true);
        Cerrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CerrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CerrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CerrarMouseExited(evt);
            }
        });
        Bg.add(Cerrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(342, 2, 25, 25));

        Recordar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Recordar.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        Recordar.setLabel(" Recordar");
        Bg.add(Recordar, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 350, -1, -1));

        JLOlvidarContraseña.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        JLOlvidarContraseña.setText("¿Olvidaste la contraseña?");
        JLOlvidarContraseña.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JLOlvidarContraseña.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JLOlvidarContraseñaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JLOlvidarContraseñaMouseExited(evt);
            }
        });
        Bg.add(JLOlvidarContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(188, 355, -1, -1));

        JLCrearCuenta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        JLCrearCuenta.setText("¿No tiene cuenta? Ingresa aqui");
        JLCrearCuenta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JLCrearCuenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JLCrearCuentaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JLCrearCuentaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JLCrearCuentaMouseExited(evt);
            }
        });
        Bg.add(JLCrearCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 460, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Bg, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Bg, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void JPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JPasswordActionPerformed

    private void JTUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTUserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JTUserActionPerformed

    private void JLBotonIngresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLBotonIngresarMouseClicked
            
    }//GEN-LAST:event_JLBotonIngresarMouseClicked

    private void CerrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarMouseClicked
        System.exit(0);
    }//GEN-LAST:event_CerrarMouseClicked

    private void BgMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BgMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_BgMousePressed

    private void BgMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BgMouseDragged
       int x = evt.getXOnScreen();
       int y = evt.getYOnScreen();
       
       this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_BgMouseDragged

    private void JTUserMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JTUserMousePressed
        if (JTUser.getText().equals(" Ejemplo@ejemplo.com")){
            JTUser.setText("");
            JTUser.setForeground(Color.BLACK);
        }
        if (String.valueOf(JPassword.getPassword()).isEmpty()){
            JPassword.setText("jPasswordField1");
            JPassword.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_JTUserMousePressed

    private void JPasswordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JPasswordMousePressed
         if (String.valueOf(JPassword.getPassword()).equals("jPasswordField1")){
            JPassword.setText("");
            JPassword.setForeground(Color.BLACK);
        }
        
        if (JTUser.getText().equals("")){
            JTUser.setText(" Ejemplo@ejemplo.com");
            JTUser.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_JPasswordMousePressed

    private void CerrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarMouseEntered
           Cerrar.setForeground(Color.MAGENTA);
    }//GEN-LAST:event_CerrarMouseEntered

    private void CerrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CerrarMouseExited
        Cerrar.setForeground(Color.yellow);
    }//GEN-LAST:event_CerrarMouseExited

    private void JLBotonIngresarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLBotonIngresarMouseEntered
        JLBotonIngresar.setForeground(Color.magenta);
    }//GEN-LAST:event_JLBotonIngresarMouseEntered

    private void JLBotonIngresarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLBotonIngresarMouseExited
        JLBotonIngresar.setForeground(Color.yellow);
    }//GEN-LAST:event_JLBotonIngresarMouseExited

    private void JLCrearCuentaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLCrearCuentaMouseEntered
        JLCrearCuenta.setForeground(Color.MAGENTA);
    }//GEN-LAST:event_JLCrearCuentaMouseEntered

    private void JLCrearCuentaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLCrearCuentaMouseExited
        JLCrearCuenta.setForeground(Color.BLACK);
    }//GEN-LAST:event_JLCrearCuentaMouseExited

    private void JLOlvidarContraseñaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLOlvidarContraseñaMouseEntered
        JLOlvidarContraseña.setForeground(Color.magenta);
    }//GEN-LAST:event_JLOlvidarContraseñaMouseEntered

    private void JLOlvidarContraseñaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLOlvidarContraseñaMouseExited
        JLOlvidarContraseña.setForeground(Color.black);
    }//GEN-LAST:event_JLOlvidarContraseñaMouseExited

    private void JLCrearCuentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JLCrearCuentaMouseClicked
        Registro verRegistro = new Registro();
        this.setVisible(false);
        verRegistro.setVisible(true);
    }//GEN-LAST:event_JLCrearCuentaMouseClicked


    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new main().setVisible(true);
            }
        });   
    }
    
    private void SetImageLabelLogo (JLabel labelName, String root ){
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(image.getImage().getScaledInstance(labelName.getWidth() , labelName.getHeight(), Image.SCALE_DEFAULT));
        labelName.setIcon(icon);
        this.repaint();
    }
    
     private void SetImageLabelBotonIngresar (JLabel labelName, String root ){
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(image.getImage().getScaledInstance(labelName.getWidth() , labelName.getHeight(), Image.SCALE_DEFAULT));
        labelName.setIcon(icon);
        this.repaint();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Bg;
    private javax.swing.JLabel Cerrar;
    private javax.swing.JLabel JLBotonIngresar;
    private javax.swing.JLabel JLCrearCuenta;
    private javax.swing.JLabel JLOlvidarContraseña;
    private javax.swing.JLabel JLPassword;
    private javax.swing.JLabel JLUser;
    private javax.swing.JPasswordField JPassword;
    private javax.swing.JSeparator JSepUser;
    private javax.swing.JTextField JTUser;
    private java.awt.Checkbox Recordar;
    private javax.swing.JSeparator jSepPassword;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
